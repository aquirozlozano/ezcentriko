# Despliegue de la web

La landing se sirve como archivos estáticos con Nginx. No necesita ejecutar Vite
en producción ni desplegar `client`, `server` o PostgreSQL.

- VPS: `2.25.210.143`
- Código: `/opt/ezcentriko`
- Versiones: `/var/www/ezcentriko/releases/`
- Versión publicada: `/var/www/ezcentriko/current` (enlace simbólico)
- Configuración: `/etc/nginx/sites-available/ezcentriko`

## Actualizar

Conectarse por SSH y ejecutar:

```sh
cd /opt/ezcentriko
git pull --ff-only
cd web
npm ci
npm run build
release="/var/www/ezcentriko/releases/$(date -u +%Y%m%dT%H%M%SZ)-$(git rev-parse --short HEAD)"
install -d -m 755 "$release"
cp -a dist/. "$release/"
chmod -R a+rX "$release"
ln -s "$release" /var/www/ezcentriko/current.next
mv -Tf /var/www/ezcentriko/current.next /var/www/ezcentriko/current
curl --fail --head http://127.0.0.1/
```

Las versiones anteriores se conservan. Para volver a una de ellas, crear
`current.next` apuntando a su ruta y sustituir `current` con el mismo `mv -Tf`.

## Nginx y dominio

La configuración inicial está en `ezcentriko.nginx`. Tras cualquier cambio:

```sh
nginx -t && systemctl reload nginx
```

Para servir el dominio por HTTPS, los registros DNS de `ezcentriko.com` y
`www.ezcentriko.com` deben apuntar a `2.25.210.143`; cualquier registro AAAA
también debe corresponder a esta VPS. Después se puede emitir un certificado
TLS e instalarlo en Nginx. La publicación inicial por IP utiliza HTTP.

No almacenar credenciales SSH en el repositorio.
